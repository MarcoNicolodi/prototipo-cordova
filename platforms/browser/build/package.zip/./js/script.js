

//window.addEventListener('load',checkIfConnected);
// console.log("oi");
// setInterval(function(){
//     if(navigator.onLine){
//         document.getElementById("connectionAdvice").innerHTML = "Online";
//         document.getElementById("connectionAdvice").className= "online";
//     } else {
//         document.getElementById("connectionAdvice").innerHTML = "Offline";
//         document.getElementById("connectionAdvice").className = "offline";
//     }
//
// },1000);

function loadPage2(url,callback){
	$.ajax({
		url: url,
		success: function(data){
			$("#app").html(data);
			if (callback && typeof callback === 'function'){
				callback();
			}
		},
		error: function(e){
			console.log(JSON.stringify(e));
			$("#app").html("<p>Ocorreu um erro ao tentar carregar a página. Por favor, tente novamente</p>");
		}
	});
}

// function _callback(){
// 	if($("#form").length){
// 	document.getElementById("form").addEventListener("submit",function(e){
// 		jQuery.support.cors = true;
// 		e.preventDefault();
// 		$.ajax({
// 			type: "post",
// 			url: url,
// 			data: {nome: $("input[name='nome']").val(),tamanho: $("input[name='tamanho']").val(),usuario_id: $("input[name='usuario_id']").val(),cidade_id: $("input[name='cidade_id']").val(),endereco:$("input[name='endereco']").val()},
// 			dataType: "json",
// 			crossDomain: true,
// 			success: function(data){
// 				console.log(data);
// 			},
// 			error: function(e){
// 				console.error("ERRO:"+JSON.stringify(e));
// 			}
// 		});
// 	});
// }
// }



function loadPage(url) {
    var xmlhttp = new XMLHttpRequest();

    // Callback function when XMLHttpRequest is ready
    xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState === 4){
            if (xmlhttp.status === 200) {
                document.getElementById('app').innerHTML = xmlhttp.responseText;
                    document.getElementById("form").addEventListener("submit",function(e){
                            jQuery.support.cors = true;
                            e.preventDefault();
                            $.ajax({
                                type: "post",
                                url: url,
                                data: {nome: $("input[name='nome']").val(),tamanho: $("input[name='tamanho']").val(),usuario_id: $("input[name='usuario_id']").val(),cidade_id: $("input[name='cidade_id']").val(),endereco:$("input[name='endereco']").val()},
                                dataType: "json",
                                crossDomain: true,
                                success: function(data){
                                    console.log(data);
                                },
                                error: function(e){
                                    console.error("ERRO:"+JSON.stringify(e));
                                }
                            })
                            // $.ajax({
                            //     type: "get",
                            //     url: "http://localhost/epagri3/propriedades.json",
                            //     //data: {nome: $("input[name='nome']").val(),tamanho: $("input[name='tamanho']").val(),usuario_id: $("input[name='usuario_id']").val(),cidade_id: $("input[name='cidade_id']").val()},
                            //     //dataType: "json",
                            //     crossDomain: true,
                            //     success: function(data){
                            //         console.log(data);
                            //     },
                            //     error: function(e){
                            //         console.error("ERRO:"+JSON.parse(e));
                            //     }
                            // })

    // $.ajax({
    //     url: 'http://localhost/webservice/livros',
    //     success: function(data){
    //         var content;
    //         content = "<table class='table table-striped'><thead><tr>" +
    //                   "<th>Nome</th>  <th>Gênero</th><th>Autor</th>" +
    //                   "<th>Preço</th><th>Ações</th></tr></thead><tbody>"
    //         $.each(data,function(k,v){
    //             content+="<tr>" +
    //                     '<td>'+v.nomelivro+'</td>'+
    //                     '<td>'+v.generolivro+'</td>'+
    //                     '<td>'+v.idautor+'</td>'+
    //                     '<td>'+v.precolivro+'</td>'+
    //                     "</tr>";
    //         });
    //         content+="</tbody></table>";
    //         $("#display").append(content);
    //
    //     },
    //     error: function(e){
    //         console.log("Error: "+e);
    //     }
    // });


                    });
            }
        }
    };
    xmlhttp.open("GET", url , true);
    xmlhttp.send();
}

//$("#linkCadastrar").on('click',loadPage2('form.html'));
